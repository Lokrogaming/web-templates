# Pages Landing

Komplette statische Landingpage für ein fiktives Analytics-Produkt. Ideal für GitHub Pages: einfach pushen, Pages auf `main` / `/` stellen, fertig.

- `index.html` – Hero, Dashboard-Mock, Features, Preise, FAQ, Footer
- `styles.css` – Dark/Light-Theme via `data-theme`
- `app.js` – mobiles Menü, Theme-Toggle, animierte Zähler, Demo-Chart, Scroll-Reveals
