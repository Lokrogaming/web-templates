// Mobiles Menü
const menuBtn = document.getElementById('menuBtn');
const navLinks = document.getElementById('navLinks');
menuBtn.addEventListener('click', () => navLinks.classList.toggle('open'));
navLinks.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => navLinks.classList.remove('open')));

// Theme-Umschalter (dark/light, wird gemerkt)
const themeBtn = document.getElementById('themeBtn');
const saved = localStorage.getItem('pulse-theme');
if (saved) document.documentElement.dataset.theme = saved;
themeBtn.addEventListener('click', () => {
  const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
  document.documentElement.dataset.theme = next;
  localStorage.setItem('pulse-theme', next);
});

// Animierte Zähler
const counters = document.querySelectorAll('[data-count]');
const cio = new IntersectionObserver((entries) => {
  entries.forEach((en) => {
    if (!en.isIntersecting) return;
    const el = en.target;
    cio.unobserve(el);
    const target = Number(el.dataset.count);
    const t0 = performance.now();
    const tick = (t) => {
      const p = Math.min(1, (t - t0) / 1200);
      el.textContent = Math.round(target * (1 - Math.pow(1 - p, 3))).toLocaleString('de-DE') + (target >= 1000 ? '+' : target === 99 ? ' %' : '');
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
}, { threshold: 0.5 });
counters.forEach((c) => cio.observe(c));

// Demo-Balkendiagramm
const chart = document.getElementById('chart');
[42, 68, 51, 80, 63, 92, 74, 88, 58, 97, 70, 84].forEach((h, i) => {
  const b = document.createElement('i');
  b.style.height = h + '%';
  b.style.left = (3 + i * 8) + '%';
  chart.appendChild(b);
});

// Scroll-Reveals
document.querySelectorAll('#features .grid article, .plan').forEach((el) => el.classList.add('reveal'));
const rio = new IntersectionObserver((entries) => {
  entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add('in'); rio.unobserve(en.target); } });
}, { threshold: 0.15 });
document.querySelectorAll('.reveal').forEach((el) => rio.observe(el));

// Jahr
document.getElementById('year').textContent = new Date().getFullYear();
