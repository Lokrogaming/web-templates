import { useMemo, useState } from 'react';

const FEATURES = [
  { title: 'Vite + React 18', text: 'Schneller Dev-Server mit HMR, schlanker Production-Build.' },
  { title: 'Komponenten', text: 'Counter, Todo-Liste und Feature-Grid als fertige Beispiele.' },
  { title: 'State & Hooks', text: 'useState und useMemo im Einsatz – ideal als Lernbasis.' },
  { title: 'Theme-Toggle', text: 'Dark/Light per State, ohne Extra-Library.' },
  { title: 'Deploy-ready', text: 'npm run build → dist/ auf Pages, Vercel oder Netlify.' },
  { title: 'Erweiterbar', text: 'Saubere Struktur für Router, Fetching und mehr.' },
];

function Counter() {
  const [n, setN] = useState(0);
  return (
    <div className="card">
      <h3>Counter</h3>
      <p className="big">{n}</p>
      <div className="row">
        <button onClick={() => setN(n - 1)}>−1</button>
        <button onClick={() => setN(0)}>Reset</button>
        <button className="accent" onClick={() => setN(n + 1)}>+1</button>
      </div>
    </div>
  );
}

function Todos() {
  const [items, setItems] = useState(['Vite verstehen', 'Komponente bauen', 'Deployen']);
  const [text, setText] = useState('');
  const open = useMemo(() => items.length, [items]);
  const add = () => {
    const v = text.trim();
    if (!v) return;
    setItems([...items, v]);
    setText('');
  };
  return (
    <div className="card">
      <h3>Todos <span className="pill">{open} offen</span></h3>
      <ul className="todos">
        {items.map((t, i) => (
          <li key={i}>{t}<button aria-label={'Entfernen: ' + t} onClick={() => setItems(items.filter((_, j) => j !== i))}>×</button></li>
        ))}
      </ul>
      <div className="row">
        <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && add()} placeholder="Neues Todo …" />
        <button className="accent" onClick={add}>Hinzufügen</button>
      </div>
    </div>
  );
}

export default function App() {
  const [theme, setTheme] = useState('dark');
  return (
    <div className="app" data-theme={theme}>
      <header className="nav">
        <b>React Starter</b>
        <span className="muted">SiteSmith Template · v1.0.0</span>
        <button className="theme" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
          {theme === 'dark' ? '☀ Light' : '◐ Dark'}
        </button>
      </header>
      <main>
        <section className="hero">
          <h1>Starte dein React-Projekt <span>in Minuten.</span></h1>
          <p>Vite + React 18 mit fertigen Beispiel-Komponenten. Klonen, <code>npm install</code>, <code>npm run dev</code> – los.</p>
        </section>
        <section className="grid2">
          <Counter />
          <Todos />
        </section>
        <section className="grid3">
          {FEATURES.map((f) => (
            <article key={f.title} className="card"><h3>{f.title}</h3><p>{f.text}</p></article>
          ))}
        </section>
      </main>
      <footer>React Starter · {new Date().getFullYear()} · MIT</footer>
    </div>
  );
}
