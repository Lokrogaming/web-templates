# React Starter

Schlanker Vite + React 18 Starter.

```powershell
npm install
npm run dev      # Dev-Server mit HMR
npm run build    # Production-Build nach dist/
```

Enthält Beispiel-Komponenten: Counter, Todo-Liste (State/Hooks), Theme-Toggle, Feature-Grid.
